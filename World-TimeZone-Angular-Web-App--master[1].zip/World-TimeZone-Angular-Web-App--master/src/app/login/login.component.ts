import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userdetails:any;
message;
  constructor(private router: Router,private service:AuthService) { }

  ngOnInit() {
  }
  SignIn(myloginform)
  {
    let loginCredentials=myloginform.form.value; 
    console.log(loginCredentials)
    let isvalid = this.service.LogIn(loginCredentials)
    console.log(isvalid);  
  }
  
  onSignup() {
    this.router.navigate(['/signup']);
  }
}
